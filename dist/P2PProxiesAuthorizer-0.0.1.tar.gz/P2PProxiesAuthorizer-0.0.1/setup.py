from setuptools import setup

setup(
    name='P2PProxiesAuthorizer',
    version='0.0.1',
    packages=['P2PProxiesAuthorizer'],
    url='https://rev.proxies.online',
    license='',
    author='Garry Lachman',
    author_email='garry@lachman.co',
    description='P2P Proxies Authorizer',
    install_requires=['urllib3'],
    py_modules='P2PProxiesAuthorizer'
)
